DSF Support for Picard Tagger.

Tested with Picard version 1.1

1) Place the entrire dsf folder into your plugins directory.
2) Start Picard
3) Enable DSF support in the "Options" -> "Plugins" menu


 
